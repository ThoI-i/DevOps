import { loadTodos } from "./render.js";
import { addAllHandler } from "./addHandler.js";
//========= 코드 실행 영역 ========//
addAllHandler();
loadTodos();