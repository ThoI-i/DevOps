//========= DOM 가져오기 영역 ========//
const $todoListUl = document.querySelector('.todo-list');
const $addBtn = document.getElementById('add');
const $todoTextInput = document.getElementById('todo-text');

export { $todoListUl, $addBtn, $todoTextInput };